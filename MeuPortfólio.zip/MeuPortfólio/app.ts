// ==========================================
// FUNCIONALIDADE A: Alternância de Tema (Dark Mode)
// ==========================================

// Seleção tipada do botão de tema do cabeçalho
const themeToggleBtn = document.querySelector<HTMLButtonElement>('#theme-toggle');

// Registro do escutador de eventos utilizando encadeamento opcional (?.)
themeToggleBtn?.addEventListener('click', () => {
    // Alterna a classe 'dark-mode' no elemento <body> da página
    document.body.classList.toggle('dark-mode');
});


// ==========================================
// FUNCIONALIDADE B: Adição Dinâmica de Projetos ou Habilidades
// ==========================================

// Seleção de elementos utilizando Type Casting explícito
const addItemForm = document.getElementById('add-item-form') as HTMLFormElement;
const itemNameInput = document.getElementById('item-name') as HTMLInputElement;
const portfolioList = document.getElementById('portfolio-list') as HTMLUListElement;

// Verificação de segurança contra valores nulos
if (addItemForm && itemNameInput && portfolioList) {
    
    // Intercepta o evento 'submit' tipado com SubmitEvent
    addItemForm.addEventListener('submit', (event: SubmitEvent) => {
        // Evita o recarregamento padrão da página ao enviar o formulário
        event.preventDefault();

        // Captura o texto digitado e remove espaços em branco nas extremidades
        const newItemName = itemNameInput.value.trim();

        // Validação contra o envio de campos vazios
        if (newItemName === "") {
            alert("Por favor, digite um nome válido para o projeto ou habilidade.");
            itemNameInput.focus();
            return;
        }

        // Cria um novo elemento <li> na memória
        const newListItem = document.createElement('li');
        
        // Estrutura interna utilizando o texto digitado
        newListItem.innerHTML = `
            <h3>${newItemName}</h3>
            <p>Novo item adicionado interativamente via TypeScript.</p>
        `;

        // Insere o novo elemento como filho da lista no DOM
        portfolioList.appendChild(newListItem);

        // Limpa o campo de entrada e devolve o foco a ele
        itemNameInput.value = '';
        itemNameInput.focus();
    });
}